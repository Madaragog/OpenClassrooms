//
//  Questions.swift
//  OpenQuiz
//
//  Created by Cedric on 31/05/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation

struct Question {
    var title = ""
    var isCorrect = false
}
