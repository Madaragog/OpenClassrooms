# Instagrid

Instagrid is an application that allows you to share frames filled with your photos.


1 - When you open the app, you can select one of the three frames available.

2 - By pressing one of the blue plus buttons it opens your photo library, so you have to pick one.

3 - Once the picture is chosen it will replace the blue plus button you pressed up stream.

4 - Filled, the frame is now ready to be shared, all you have to do is to swipe it up in portrait mode or left in landscape mode.

5 - You're done and can create another one if necessary.
