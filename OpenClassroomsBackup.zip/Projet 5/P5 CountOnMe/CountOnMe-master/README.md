# CountOnMe

Count on me is a simple calculator with divison, multiplication, addition and substraction.

Icon made by Smashicons from www.flaticon.com
Icon link: https://www.flaticon.com/free-icon/calculator_148787#term=calculator&page=1&position=3
