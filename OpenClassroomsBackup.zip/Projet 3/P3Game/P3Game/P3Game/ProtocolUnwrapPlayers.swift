//
//  ProtocoleUnwrapPlayers.swift
//  P3Game
//
//  Created by Cedric on 12/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation

protocol ProtocolUnwrapedPlayers {
    func unwrapPlayers(player: Player)
}
