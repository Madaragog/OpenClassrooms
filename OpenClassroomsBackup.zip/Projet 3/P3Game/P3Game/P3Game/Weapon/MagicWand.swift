//
//  MagicWand.swift
//  P3Game
//
//  Created by Cedric on 29/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class MagicWand: Weapon {
    init() {
        super.init(name: "MagicWand", damage: -7)
    }
}
