//
//  MagicalGrimoire .swift
//  P3Game
//
//  Created by Cedric on 29/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class MagicalGrimoire : Weapon {
    init() {
        super.init(name: "MagicalGrimoire ", damage: -15)
    }
}
