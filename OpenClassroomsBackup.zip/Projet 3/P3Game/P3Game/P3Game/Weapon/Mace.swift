//
//  e.swift
//  P3Game
//
//  Created by Cedric on 12/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class Mace: Weapon {
    init() {
        super.init(name: "Mace", damage: 16)
    }
}
