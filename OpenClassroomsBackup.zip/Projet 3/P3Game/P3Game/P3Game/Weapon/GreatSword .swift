//
//  GreatSword .swift
//  P3Game
//
//  Created by Cedric on 29/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class GreatSword : Weapon {
    init() {
        super.init(name: "GreatSword ", damage: 17)
    }
}
