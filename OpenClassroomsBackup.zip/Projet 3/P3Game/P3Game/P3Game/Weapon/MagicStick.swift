//
//  File.swift
//  P3Game
//
//  Created by Cedric on 12/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class MagicStick: Weapon {
    init() {
        super.init(name: "Magic Stick", damage: -10)
    }
}
