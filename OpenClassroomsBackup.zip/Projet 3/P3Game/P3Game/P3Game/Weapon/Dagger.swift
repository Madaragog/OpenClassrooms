//
//  Dagger.swift
//  P3Game
//
//  Created by Cedric on 29/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class Dagger: Weapon {
    init() {
        super.init(name: "Dagger", damage: 13)
    }
}
