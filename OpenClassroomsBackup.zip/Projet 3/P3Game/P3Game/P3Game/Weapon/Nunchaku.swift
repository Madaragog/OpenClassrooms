//
//  Nunchaku.swift
//  P3Game
//
//  Created by Cedric on 29/04/2019.
//  Copyright © 2019 Cedric. All rights reserved.
//

import Foundation


class Nunchaku: Weapon {
    init() {
        super.init(name: "Nunchaku", damage: 10)
    }
}
